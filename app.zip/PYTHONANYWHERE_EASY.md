# 🐍 PythonAnywhere - Easy Deployment (No GitHub!)

## معهد خباب - Exam Results System
### **NO GITHUB NEEDED!** ✅

---

## 📋 TALLAABOOYIN / STEPS

### ✅ STEP 1: Create Account (2 min)

1. **Tag:** https://www.pythonanywhere.com
2. **Click:** "Start running Python online"
3. **Choose:** "Create a Beginner account" (FREE)
4. **Fill form:**
   - Username
   - Email
   - Password
5. **Click:** "Register"
6. **Verify email**
7. ✅ **Done!**

---

### ✅ STEP 2: Upload Files (5 min)

#### A) ZIP your project:

1. **Go to:** `C:\khabab Exam`
2. **Select all** files and folders
3. **Right-click** → "Send to" → "Compressed (zipped) folder"
4. **Name:** `khabab-exam.zip`

#### B) Upload to PythonAnywhere:

1. **Click:** "Files" tab (top menu)
2. **Click:** "Upload a file"
3. **Browse:** Select `khabab-exam.zip`
4. **Click:** "Upload"
5. **Wait** for upload

#### C) Extract ZIP:

1. **Click:** "Consoles" tab
2. **Click:** "Bash" (start a new console)
3. **Type:**
```bash
unzip khabab-exam.zip -d khabab-exam
cd khabab-exam
```

4. ✅ **Done!** Files uploaded

---

### ✅ STEP 3: Install Requirements (3 min)

**In the Bash console:**

```bash
pip3 install --user -r requirements.txt
```

**Wait** 2-3 minutes for installation

---

### ✅ STEP 4: Create Web App (5 min)

#### A) Go to Web tab:

1. **Click:** "Web" tab (top)
2. **Click:** "Add a new web app"
3. **Click:** "Next"
4. **Select:** "Manual configuration"
5. **Select:** "Python 3.10"
6. **Click:** "Next"

#### B) Configure paths:

**Source code:**
```
/home/YOUR-USERNAME/khabab-exam
```

**Working directory:**
```
/home/YOUR-USERNAME/khabab-exam
```

#### C) Edit WSGI file:

1. **Click** link to WSGI configuration file
2. **Delete everything**
3. **Paste this:**

```python
import sys
import os

# Add project directory
project_home = '/home/YOUR-USERNAME/khabab-exam'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# Import Flask app
from app import app as application

# Set config
application.config['DEBUG'] = False
```

**Replace** `YOUR-USERNAME` with your actual username!

4. **Click:** "Save" (top right)

#### D) Set environment variables:

**Scroll down** to "Environment variables" section

**Click** "Add" and add:

```
Variable: ADMIN_PASSWORD
Value: YourSecurePassword123
```

```
Variable: SECRET_KEY
Value: random-secret-key-minimum-32-characters
```

```
Variable: SCHOOL_NAME
Value: معهد خباب
```

#### E) Reload web app:

1. **Scroll to top**
2. **Click:** Big green **"Reload"** button
3. **Wait** 30 seconds

---

### ✅ STEP 5: Your Website is LIVE! 🎉

**URL:**
```
https://YOUR-USERNAME.pythonanywhere.com
```

**Admin Panel:**
```
https://YOUR-USERNAME.pythonanywhere.com/admin/login
```

---

## 🎯 ADVANTAGES OF PYTHONANYWHERE

✅ No GitHub needed
✅ **Permanent storage** (files don't get deleted)
✅ Always on (doesn't sleep)
✅ Easy to manage
✅ Good for schools
✅ Free SSL (https)

---

## 🔄 UPDATE YOUR WEBSITE

### When you make changes:

1. **Go to:** "Files" tab
2. **Navigate to** your files
3. **Click** file name to edit
4. **Make changes**
5. **Save**
6. **Go to:** "Web" tab
7. **Click:** "Reload"

### Or upload new version:

1. **Upload new ZIP**
2. **Extract** (overwrite old files)
3. **Reload** web app

---

## ⚠️ FREE TIER LIMITATIONS

1. **One web app only**
2. **Custom domain** needs paid plan
3. **Limited CPU time** (should be fine for results system)

**Upgrade:** $5/month for more features

---

## 🆘 TROUBLESHOOTING

### Error 500 - Internal Server Error?

**Check logs:**
1. Web tab → Log files
2. Click "error log"
3. Fix errors shown

**Common fix:**
- Wrong paths in WSGI file
- Missing requirements

### Logo not showing?

**Check:**
```bash
ls /home/YOUR-USERNAME/khabab-exam/assets/
```

Should see `logo.png`

### Can't login?

**Check** environment variables are set correctly

---

## ✅ CHECKLIST

- [ ] Account created
- [ ] Files uploaded
- [ ] Requirements installed
- [ ] Web app created
- [ ] WSGI configured
- [ ] Environment variables set
- [ ] Website reloaded
- [ ] Website loads
- [ ] Logo shows
- [ ] Admin login works

---

## 🎉 SUCCESS!

**معهد خباب** is now ONLINE!

**Your URL:**
```
https://YOUR-USERNAME.pythonanywhere.com
```

**Share with students!** ✅

---

**Mahadsanid!** 🙏

