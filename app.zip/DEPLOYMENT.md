# 🚀 Deployment Guide

This guide covers multiple deployment options for the Exam Results Management System.

## Table of Contents
- [Deploy to Render (Recommended - Free)](#deploy-to-render)
- [Deploy to PythonAnywhere](#deploy-to-pythonanywhere)
- [Deploy to Replit](#deploy-to-replit)
- [Deploy to Heroku](#deploy-to-heroku)
- [Local Network Deployment](#local-network-deployment)

---

## Deploy to Render

[Render](https://render.com) offers free hosting for web applications with automatic SSL.

### Step 1: Prepare Your Code

1. Create a `render.yaml` file in your project root:

```yaml
services:
  - type: web
    name: exam-results-system
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: gunicorn app:app
    envVars:
      - key: PYTHON_VERSION
        value: 3.11.0
      - key: SECRET_KEY
        generateValue: true
      - key: ADMIN_USERNAME
        value: admin
      - key: ADMIN_PASSWORD
        sync: false
```

2. Add `gunicorn` to `requirements.txt`:
```bash
echo "gunicorn==21.2.0" >> requirements.txt
```

### Step 2: Deploy

1. **Create a GitHub Repository**
   - Push your code to GitHub
   
2. **Sign up on Render**
   - Go to [render.com](https://render.com)
   - Sign up with your GitHub account

3. **Create New Web Service**
   - Click "New" → "Web Service"
   - Connect your GitHub repository
   - Render will auto-detect the `render.yaml`

4. **Configure Environment Variables**
   - Set `ADMIN_PASSWORD` to a secure password
   - Set `SCHOOL_NAME` to your school name

5. **Deploy**
   - Click "Create Web Service"
   - Wait for deployment (2-5 minutes)
   - Your app will be live at `https://your-app-name.onrender.com`

### Step 3: Upload Your Logo

Use Render's shell or upload via Git to add your school logo to `static/images/logo.png`.

---

## Deploy to PythonAnywhere

[PythonAnywhere](https://www.pythonanywhere.com) offers free Python hosting.

### Step 1: Create Account

1. Sign up at [pythonanywhere.com](https://www.pythonanywhere.com)
2. Choose the free "Beginner" plan

### Step 2: Upload Files

1. **Open Bash Console**
   - Go to "Consoles" → "Bash"

2. **Clone or Upload Your Code**
   ```bash
   git clone https://github.com/your-username/exam-results-system.git
   cd exam-results-system
   ```
   
   Or upload via "Files" tab.

3. **Install Dependencies**
   ```bash
   pip install --user -r requirements.txt
   ```

### Step 3: Configure Web App

1. **Go to "Web" tab**
   - Click "Add a new web app"
   - Choose "Manual configuration"
   - Select Python 3.10

2. **Set Source Code Path**
   ```
   /home/yourusername/exam-results-system
   ```

3. **Set Working Directory**
   ```
   /home/yourusername/exam-results-system
   ```

4. **Edit WSGI Configuration**
   - Click on WSGI configuration file
   - Replace content with:
   
   ```python
   import sys
   import os
   
   project_folder = '/home/yourusername/exam-results-system'
   
   if project_folder not in sys.path:
       sys.path.insert(0, project_folder)
   
   from app import app as application
   ```

5. **Reload Web App**
   - Click "Reload" button
   - Your app is live at `https://yourusername.pythonanywhere.com`

---

## Deploy to Replit

[Replit](https://replit.com) provides instant hosting with code editor.

### Step 1: Import Project

1. Go to [replit.com](https://replit.com)
2. Click "Create Repl"
3. Choose "Import from GitHub" or "Upload Files"

### Step 2: Configure

1. **Install Dependencies**
   - Replit will auto-detect `requirements.txt`
   - Or run: `pip install -r requirements.txt`

2. **Create `.replit` file**:
   ```toml
   run = "python app.py"
   
   [env]
   PYTHONUNBUFFERED = "1"
   ```

3. **Set Environment Variables**
   - Click "Secrets" (lock icon)
   - Add:
     - `ADMIN_USERNAME`
     - `ADMIN_PASSWORD`
     - `SECRET_KEY`
     - `SCHOOL_NAME`

### Step 3: Run

1. Click "Run" button
2. Your app will be live at `https://your-repl-name.your-username.repl.co`

---

## Deploy to Heroku

[Heroku](https://heroku.com) offers free tier with dynos.

### Step 1: Prepare Files

1. **Create `Procfile`**:
   ```
   web: gunicorn app:app
   ```

2. **Create `runtime.txt`**:
   ```
   python-3.11.0
   ```

3. **Update `requirements.txt`**:
   ```bash
   echo "gunicorn==21.2.0" >> requirements.txt
   ```

### Step 2: Deploy

1. **Install Heroku CLI**
   ```bash
   # Download from https://devcenter.heroku.com/articles/heroku-cli
   ```

2. **Login and Create App**
   ```bash
   heroku login
   heroku create your-exam-results-app
   ```

3. **Set Environment Variables**
   ```bash
   heroku config:set ADMIN_USERNAME=admin
   heroku config:set ADMIN_PASSWORD=yourpassword
   heroku config:set SECRET_KEY=your-secret-key
   heroku config:set SCHOOL_NAME="Your School Name"
   ```

4. **Deploy**
   ```bash
   git add .
   git commit -m "Initial deployment"
   git push heroku main
   ```

5. **Open App**
   ```bash
   heroku open
   ```

---

## Local Network Deployment

Deploy on your school's local network for internal access.

### Option 1: Windows (Simple)

1. **Run with accessible host**:
   ```bash
   python app.py
   ```
   App runs on `http://0.0.0.0:5000`

2. **Find Your IP Address**:
   ```bash
   ipconfig
   ```
   Look for "IPv4 Address" (e.g., 192.168.1.100)

3. **Access from Other Devices**:
   - Same network: `http://192.168.1.100:5000`

### Option 2: Production Server (Recommended)

1. **Install Waitress** (Windows) or **Gunicorn** (Linux/Mac):
   ```bash
   pip install waitress
   # or
   pip install gunicorn
   ```

2. **Create `run_production.py`**:
   ```python
   from waitress import serve
   from app import app
   
   if __name__ == '__main__':
       print("Server starting on http://0.0.0.0:8080")
       serve(app, host='0.0.0.0', port=8080)
   ```

3. **Run**:
   ```bash
   python run_production.py
   ```

### Option 3: Docker Deployment

1. **Create `Dockerfile`**:
   ```dockerfile
   FROM python:3.11-slim
   
   WORKDIR /app
   
   COPY requirements.txt .
   RUN pip install --no-cache-dir -r requirements.txt
   
   COPY . .
   
   EXPOSE 5000
   
   CMD ["python", "app.py"]
   ```

2. **Create `docker-compose.yml`**:
   ```yaml
   version: '3.8'
   services:
     web:
       build: .
       ports:
         - "5000:5000"
       environment:
         - ADMIN_USERNAME=admin
         - ADMIN_PASSWORD=admin123
         - SCHOOL_NAME=ABC School
       volumes:
         - ./data:/app/data
         - ./static/qrcodes:/app/static/qrcodes
   ```

3. **Run**:
   ```bash
   docker-compose up -d
   ```

---

## Security Checklist for Production

- [ ] Change default admin credentials
- [ ] Set strong SECRET_KEY
- [ ] Use environment variables for sensitive data
- [ ] Enable HTTPS/SSL
- [ ] Set up firewall rules
- [ ] Regular backups of data folder
- [ ] Update dependencies regularly
- [ ] Monitor application logs
- [ ] Implement rate limiting
- [ ] Set up proper error handling

---

## Custom Domain Setup

### For Render:
1. Go to Settings → Custom Domains
2. Add your domain
3. Update DNS records as instructed

### For PythonAnywhere:
1. Upgrade to paid plan
2. Go to Web tab → Custom domains
3. Follow DNS configuration

---

## Backup Strategy

### Important Folders to Backup:

1. **data/** - Contains uploaded CSV files
2. **static/qrcodes/** - Contains generated QR codes
3. **config.py** - Contains configuration

### Automated Backup Script:

```bash
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="backups/backup_$DATE"

mkdir -p $BACKUP_DIR
cp -r data $BACKUP_DIR/
cp -r static/qrcodes $BACKUP_DIR/
cp config.py $BACKUP_DIR/

echo "Backup created at $BACKUP_DIR"
```

Run daily with cron:
```bash
0 2 * * * /path/to/backup.sh
```

---

## Monitoring & Maintenance

### Check Application Health:
```bash
curl -I https://your-app-url.com
```

### View Logs:

**Render:**
- Dashboard → Logs tab

**PythonAnywhere:**
- Web tab → Log files

**Heroku:**
```bash
heroku logs --tail
```

### Update Application:

```bash
git pull origin main
pip install -r requirements.txt
# Restart your server
```

---

## Troubleshooting Common Issues

### Issue: QR Codes Not Generating on Hosted Server

**Solution:** Ensure write permissions for `static/qrcodes/` folder
```bash
chmod 755 static/qrcodes
```

### Issue: 502 Bad Gateway

**Solution:** Check if application is running and port is correct

### Issue: Static Files Not Loading

**Solution:** Configure static file serving in your WSGI/deployment config

---

## Performance Optimization

1. **Enable Caching**:
   - Add Flask-Caching for result pages

2. **Compress Static Files**:
   - Use Flask-Compress

3. **CDN for Assets**:
   - Upload logo to CDN
   - Reference CDN URL in config

4. **Database Migration** (for large schools):
   - Consider migrating from CSV to SQLite/PostgreSQL

---

## Need Help?

- Check application logs
- Review configuration files
- Test locally first
- Contact hosting support

**Happy Deploying! 🚀**

