from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
import os
import pandas as pd
import qrcode
from werkzeug.utils import secure_filename
from config import Config
import json
from io import BytesIO

app = Flask(__name__)
app.config.from_object(Config)

# Ensure directories exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['QR_CODE_FOLDER'], exist_ok=True)
os.makedirs('assets', exist_ok=True)

# Global variable to track results publication status
results_status = {
    'published': False,
    'total_students': 0
}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def generate_qr_code(exam_code, base_url):
    """Generate QR code for student exam code"""
    # Create URL for student result page
    result_url = f"{base_url}/result/{exam_code}"

    # Generate QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(result_url)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")

    # Save QR code
    qr_path = os.path.join(app.config['QR_CODE_FOLDER'], f"{exam_code}.png")
    img.save(qr_path)

    return qr_path


def load_student_data():
    """Load student data from CSV"""
    csv_path = os.path.join(app.config['UPLOAD_FOLDER'], 'students.csv')
    if os.path.exists(csv_path):
        try:
            df = pd.read_csv(csv_path)
            return df.to_dict('records')
        except Exception as e:
            print(f"Error loading CSV: {e}")
            return []
    return []


def get_student_by_exam_code(exam_code):
    """Get student data by exam code"""
    students = load_student_data()
    for student in students:
        if str(student.get('ExamCode')).strip().upper() == str(exam_code).strip().upper():
            return student
    return None

# Routes


@app.route('/')
def index():
    """Homepage - redirect to student search"""
    return redirect(url_for('student_search'))


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Admin login page"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if username == app.config['ADMIN_USERNAME'] and password == app.config['ADMIN_PASSWORD']:
            session['admin_logged_in'] = True
            flash('Login successful!', 'success')
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid credentials!', 'error')

    return render_template('admin_login.html', school_name=app.config['SCHOOL_NAME'])


@app.route('/admin/logout')
def admin_logout():
    """Admin logout"""
    session.pop('admin_logged_in', None)
    flash('Logged out successfully!', 'success')
    return redirect(url_for('admin_login'))


@app.route('/admin/dashboard')
def admin_dashboard():
    """Admin dashboard"""
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))

    students = load_student_data()
    return render_template('admin_dashboard.html',
                           school_name=app.config['SCHOOL_NAME'],
                           students=students,
                           results_published=results_status['published'],
                           total_students=len(students))


@app.route('/admin/upload', methods=['POST'])
def upload_csv():
    """Handle CSV upload"""
    if not session.get('admin_logged_in'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401

    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file uploaded'}), 400

    file = request.files['file']

    if file.filename == '':
        return jsonify({'success': False, 'message': 'No file selected'}), 400

    if file and allowed_file(file.filename):
        try:
            # Save CSV
            filename = secure_filename('students.csv')
            csv_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(csv_path)

            # Read and validate CSV
            df = pd.read_csv(csv_path)
            required_columns = ['Name', 'StudentID',
                                'ExamCode', 'Marks', 'Grade']

            if not all(col in df.columns for col in required_columns):
                os.remove(csv_path)
                return jsonify({'success': False, 'message': f'CSV must contain columns: {", ".join(required_columns)}'}), 400

            # Generate QR codes for all students
            base_url = request.url_root.rstrip('/')
            for _, row in df.iterrows():
                exam_code = str(row['ExamCode']).strip()
                generate_qr_code(exam_code, base_url)

            results_status['total_students'] = len(df)

            flash(
                f'Successfully uploaded data for {len(df)} students!', 'success')
            return jsonify({'success': True, 'message': f'Uploaded {len(df)} students', 'count': len(df)})

        except Exception as e:
            return jsonify({'success': False, 'message': f'Error processing CSV: {str(e)}'}), 400

    return jsonify({'success': False, 'message': 'Invalid file type'}), 400


@app.route('/admin/publish', methods=['POST'])
def publish_results():
    """Publish or unpublish results"""
    if not session.get('admin_logged_in'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401

    action = request.json.get('action')

    if action == 'publish':
        results_status['published'] = True
        message = 'Results published successfully!'
    else:
        results_status['published'] = False
        message = 'Results unpublished!'

    return jsonify({'success': True, 'message': message, 'published': results_status['published']})


@app.route('/search')
def student_search():
    """Student search page"""
    return render_template('student_search.html', school_name=app.config['SCHOOL_NAME'])


@app.route('/result/<exam_code>')
def view_result(exam_code):
    """View student result"""
    # Check if results are published
    if not results_status['published']:
        return render_template('result.html',
                               school_name=app.config['SCHOOL_NAME'],
                               not_published=True,
                               exam_code=exam_code)

    # Get student data
    student = get_student_by_exam_code(exam_code)

    if not student:
        return render_template('result.html',
                               school_name=app.config['SCHOOL_NAME'],
                               not_found=True,
                               exam_code=exam_code)

    return render_template('result.html',
                           school_name=app.config['SCHOOL_NAME'],
                           student=student)


@app.route('/exam-card/<exam_code>')
def exam_card(exam_code):
    """Generate printable exam card"""
    student = get_student_by_exam_code(exam_code)

    if not student:
        flash('Student not found!', 'error')
        return redirect(url_for('admin_dashboard'))

    # Check if QR code exists
    qr_path = os.path.join(app.config['QR_CODE_FOLDER'], f"{exam_code}.png")
    if not os.path.exists(qr_path):
        base_url = request.url_root.rstrip('/')
        generate_qr_code(exam_code, base_url)

    return render_template('exam_card.html',
                           school_name=app.config['SCHOOL_NAME'],
                           student=student,
                           exam_code=exam_code)


@app.route('/admin/download-all-cards')
def download_all_cards():
    """Generate page with all exam cards for printing"""
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))

    students = load_student_data()

    # Generate QR codes for any missing students
    base_url = request.url_root.rstrip('/')
    for student in students:
        exam_code = str(student.get('ExamCode', '')).strip()
        qr_path = os.path.join(
            app.config['QR_CODE_FOLDER'], f"{exam_code}.png")
        if not os.path.exists(qr_path):
            generate_qr_code(exam_code, base_url)

    return render_template('exam_card.html',
                           school_name=app.config['SCHOOL_NAME'],
                           students=students,
                           print_all=True)


@app.route('/api/check-status')
def check_status():
    """API endpoint to check results publication status"""
    return jsonify({
        'published': results_status['published'],
        'total_students': results_status['total_students']
    })


if __name__ == '__main__':
    import os
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=False, host='0.0.0.0', port=port)
