import os


class Config:
    # Security
    SECRET_KEY = os.environ.get(
        'SECRET_KEY') or 'dev-secret-key-change-in-production'

    # Admin Credentials (Change these in production!)
    ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME') or 'admin'
    ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD') or 'admin123'

    # School Information
    SCHOOL_NAME = os.environ.get('SCHOOL_NAME') or 'معهد خباب'
    SCHOOL_LOGO = 'assets/logo.png'

    # File paths
    UPLOAD_FOLDER = 'data'
    QR_CODE_FOLDER = 'static/qrcodes'
    ALLOWED_EXTENSIONS = {'csv'}

    # Results published status
    RESULTS_PUBLISHED = False
