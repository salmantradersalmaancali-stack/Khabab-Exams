# 🎯 Quick Setup Guide

Follow these simple steps to get your Exam Results System running in 5 minutes!

## 📋 Prerequisites Check

Before starting, make sure you have:
- ✅ Python 3.8 or higher installed
- ✅ Internet connection (for installing packages)
- ✅ Text editor (optional, for customization)

### Check Python Version
```bash
python --version
```
Should show `Python 3.8.x` or higher.

---

## 🚀 Installation Steps

### Step 1: Open Terminal/Command Prompt

**Windows:**
- Press `Win + R`, type `cmd`, press Enter

**Mac/Linux:**
- Press `Cmd + Space`, type `terminal`, press Enter

### Step 2: Navigate to Project Folder

```bash
cd path/to/exam-results-system
```

Example:
```bash
cd C:\Users\YourName\Desktop\exam-results-system
```

### Step 3: Install Required Packages

```bash
pip install -r requirements.txt
```

Wait for installation to complete (1-2 minutes).

### Step 4: Add Your School Logo (Optional)

Place your school's logo in the `assets` folder as `logo.png`:
- Recommended size: 400x400 pixels
- Format: PNG or JPG
- Keep the filename as `logo.png`

### Step 5: Customize School Name (Optional)

Edit `config.py` and change:
```python
SCHOOL_NAME = 'Your School Name Here'
```

### Step 6: Start the Application

```bash
python app.py
```

You should see:
```
* Running on http://0.0.0.0:5000
* Running on http://127.0.0.1:5000
```

### Step 7: Open in Browser

Open your web browser and go to:
```
http://localhost:5000
```

---

## 🎓 First Time Use

### Login to Admin Panel

1. Click "Admin Login" or go to `http://localhost:5000/admin/login`
2. Enter default credentials:
   - **Username:** `admin`
   - **Password:** `admin123`
3. Click "Login"

### Upload Student Data

1. In the admin dashboard, find "Upload Student Data" section
2. Click "Download Sample CSV" to see the format
3. Prepare your CSV file with student data:
   - Required columns: Name, StudentID, ExamCode, Marks, Grade
   - Optional columns: Subject, ExamDate
4. Click "Choose CSV File" and select your file
5. Click "Upload CSV"
6. Wait for QR codes to be generated

### Publish Results

1. Click "Publish Results" button in the dashboard
2. Results are now visible to students!

### Print Exam Cards

1. Click "Print All Exam Cards" for bulk printing
2. Or click "Exam Card" next to individual students
3. Use browser print function (Ctrl+P or Cmd+P)

---

## 📝 CSV File Format

Your CSV must have these columns (exact names):

| Column | Description | Example |
|--------|-------------|---------|
| Name | Student name | John Doe |
| StudentID | Student ID number | 2024001 |
| ExamCode | Unique exam code | EXAM2024001 |
| Marks | Marks obtained | 85 |
| Grade | Grade letter | A |
| Subject | Subject name (optional) | Mathematics |
| ExamDate | Exam date (optional) | 2024-10-15 |

### Example CSV Content:
```csv
Name,StudentID,ExamCode,Marks,Grade,Subject,ExamDate
John Doe,2024001,EXAM2024001,85,A,Mathematics,2024-10-15
Jane Smith,2024002,EXAM2024002,92,A+,Mathematics,2024-10-15
Mike Johnson,2024003,EXAM2024003,78,B+,Mathematics,2024-10-15
```

A sample file is provided: `data/sample_students.csv`

---

## 👨‍🎓 For Students

### View Results

1. Go to the homepage
2. Enter your Exam Code (e.g., EXAM2024001)
3. Click "View Result"

### Scan QR Code

1. Use your phone's camera or QR scanner app
2. Scan the QR code on your exam card
3. Result opens automatically in browser

### Print Result

1. On the result page, click "Print Result"
2. Or use Ctrl+P / Cmd+P
3. Save as PDF or print directly

---

## 🔧 Customization

### Change Admin Password

Edit `config.py`:
```python
ADMIN_USERNAME = 'your_username'
ADMIN_PASSWORD = 'your_secure_password'
```

### Change School Name

Edit `config.py`:
```python
SCHOOL_NAME = 'ABC International School'
```

### Change Colors (Advanced)

Edit `static/css/style.css` and modify CSS variables:
```css
:root {
    --primary-color: #2563eb;  /* Main blue color */
    --success-color: #16a34a;  /* Green for success */
}
```

---

## ❓ Troubleshooting

### Problem: "pip is not recognized"

**Solution:** Install Python from [python.org](https://python.org) and check "Add to PATH"

### Problem: "Port 5000 already in use"

**Solution 1:** Stop other applications using port 5000

**Solution 2:** Change port in `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=8080)
```
Then access at `http://localhost:8080`

### Problem: QR codes not generating

**Solution:** 
1. Check if `static/qrcodes/` folder exists
2. Create it manually if missing
3. Ensure write permissions

### Problem: CSV upload fails

**Solution:**
1. Check CSV format matches example
2. Ensure no special characters in exam codes
3. Save CSV as UTF-8 encoding

### Problem: Results not showing after publishing

**Solution:**
1. Clear browser cache (Ctrl+Shift+Delete)
2. Try in incognito/private mode
3. Check if exam code is exactly correct

---

## 🌐 Access from Other Devices

### On Same Network (School LAN)

1. Find your computer's IP address:

**Windows:**
```bash
ipconfig
```
Look for "IPv4 Address" (e.g., 192.168.1.100)

**Mac/Linux:**
```bash
ifconfig | grep inet
```

2. Other devices access at:
```
http://192.168.1.100:5000
```

### On Internet (Public Access)

See [DEPLOYMENT.md](DEPLOYMENT.md) for hosting on:
- Render (Free, Recommended)
- PythonAnywhere
- Heroku
- Replit

---

## 📱 QR Code Scanner Apps

Students can use these apps to scan exam card QR codes:

**iOS:**
- Built-in Camera app
- QR Code Reader by Scan

**Android:**
- Google Lens
- QR & Barcode Scanner
- Built-in camera (on newer phones)

---

## 💾 Backup Your Data

### Important Files to Backup:

1. `data/students.csv` - Student data
2. `static/qrcodes/` - Generated QR codes
3. `config.py` - Your settings

### Simple Backup:

Copy these folders/files to:
- External drive
- Cloud storage (Google Drive, Dropbox)
- Another computer

### Schedule Regular Backups:

- Daily: If actively using
- Weekly: For occasional use
- After each CSV upload

---

## 🔐 Security Tips

### For Production Use:

1. **Change default password** immediately
2. **Use strong passwords** (12+ characters, mixed case, numbers, symbols)
3. **Don't share admin credentials** with students
4. **Backup regularly**
5. **Keep software updated**

### Recommended Password:
❌ Bad: `admin123`, `password`, `school123`
✅ Good: `Sc#00l@2024!Exam`

---

## 📞 Getting Help

### Check These First:

1. ✅ README.md - General information
2. ✅ This guide - Setup help
3. ✅ DEPLOYMENT.md - Hosting online
4. ✅ Troubleshooting section above

### Still Need Help?

Create an issue with:
- What you were trying to do
- What happened instead
- Error messages (if any)
- Screenshots (helpful!)

---

## ✅ Setup Checklist

Before going live, verify:

- [ ] Python installed and working
- [ ] All packages installed (`pip install -r requirements.txt`)
- [ ] School logo added
- [ ] School name updated in config
- [ ] Admin password changed
- [ ] Sample CSV uploaded and tested
- [ ] Results publishing tested
- [ ] Exam cards print correctly
- [ ] QR codes scan properly
- [ ] Accessible from other devices (if needed)

---

## 🎉 You're All Set!

Your Exam Results System is ready to use!

**Next Steps:**
1. Prepare your student data CSV
2. Upload to admin panel
3. Print exam cards
4. Publish results when ready
5. Share the link with students

**Need to deploy online?** See [DEPLOYMENT.md](DEPLOYMENT.md)

**Have questions?** Check the troubleshooting section above!

---

**Happy Teaching! 📚✨**

