# 🚀 Render Deployment - Tilmaamaha Fudud

## معهد خباب - Exam Results System

---

## 📋 TALLAABOOYIN 5 / 5 STEPS ONLY

### ✅ STEP 1: GitHub Account Samee (2 daqiiqo)

1. Tag: **https://github.com**
2. Click: **"Sign up"**
3. Buuxi:
   - Email address
   - Password (adag/strong)
   - Username
4. Verify email-kaaga
5. ✅ **Done!**

---

### ✅ STEP 2: Install Git (3 daqiiqo)

1. **Download Git:**
   - Windows: https://git-scm.com/download/win
   - Download ayaa bilaabmaysa automatically

2. **Install:**
   - Double-click downloaded file
   - Click **"Next"** ilaa uu dhammaado
   - Click **"Finish"**

3. **Verify (optional):**
   ```bash
   git --version
   ```
   Waa inuu soo bandhigaa: `git version 2.x.x`

4. ✅ **Done!**

---

### ✅ STEP 3: Upload Code to GitHub (5 daqiiqo)

#### A) Open Command Prompt in project folder:

**Option 1 (Easy):**
1. Fur folder: `C:\khabab Exam`
2. Click address bar (meesha uu qoran yahay folder path)
3. Qor: `cmd` oo riix Enter
4. Command Prompt ayaa furmaya in that folder

**Option 2:**
1. Windows key riix
2. Qor: `cmd`
3. Riix Enter
4. Qor: `cd "C:\khabab Exam"`

#### B) Configure Git (First time only):

```bash
git config --global user.name "Khabab Institute"
git config --global user.email "your.email@example.com"
```

#### C) Upload code:

```bash
# 1. Initialize
git init

# 2. Add all files
git add .

# 3. Commit
git commit -m "معهد خباب Exam System"
```

#### D) Create GitHub Repository:

1. Tag: **https://github.com/new**
2. Repository name: `khabab-exam-system`
3. Keep everything else default
4. Click: **"Create repository"**

#### E) Push code:

```bash
# Copy from GitHub page and paste (replace YOUR-USERNAME)
git remote add origin https://github.com/YOUR-USERNAME/khabab-exam-system.git
git branch -M main
git push -u origin main
```

Ka dib riix Enter. Type password haddii la waydiyo.

5. ✅ **Done!** Code is now on GitHub!

---

### ✅ STEP 4: Deploy on Render (7 daqiiqo)

#### A) Create Render Account:

1. Tag: **https://render.com**
2. Click: **"Get Started for Free"**
3. Click: **"Continue with GitHub"**
4. Authorize Render
5. ✅ Logged in!

#### B) Create Web Service:

1. Click: **"New +"** (top right)
2. Click: **"Web Service"**
3. Find your repository: `khabab-exam-system`
4. Click: **"Connect"**

#### C) Configure Service:

**Basic Settings:**
- **Name:** `khabab-exam` (ama magac kale)
- **Region:** `Oregon (US West)` ama mid dhow
- **Branch:** `main` ✓
- **Root Directory:** (ka tag empty)
- **Runtime:** `Python 3`

**Build & Deploy:**
- **Build Command:** `pip install -r requirements.txt`
- **Start Command:** `gunicorn app:app`

**Instance Type:**
- Select: **"Free"** ✓

#### D) Add Environment Variables (MUHIIM!):

1. Scroll down to **"Environment Variables"**
2. Click: **"Add Environment Variable"**

**Add these 3:**

```
Key: ADMIN_PASSWORD
Value: YourSecurePassword123
```

```
Key: SECRET_KEY
Value: khabab-institute-secret-key-2024-random-text-here
```

```
Key: SCHOOL_NAME
Value: معهد خباب
```

3. Click **"Save Changes"** haddii uu jiro

#### E) Deploy!

1. Scroll to bottom
2. Click: **"Create Web Service"**
3. **WAIT:** 5-10 daqiiqo (first time is slow)
4. Daawasho logs - waxaa ku arki doontaa:
   - "Installing dependencies..."
   - "Starting server..."
   - "Live" ✅

5. ✅ **Done!** Website is ONLINE!

---

### ✅ STEP 5: Test Your Website! 🎉

#### Your URLs:

**Student Portal:**
```
https://khabab-exam.onrender.com
```

**Admin Panel:**
```
https://khabab-exam.onrender.com/admin/login
```

**Admin Credentials:**
- Username: `admin`
- Password: (whatever you set in ADMIN_PASSWORD)

#### Test Checklist:

1. ✅ Open student portal URL
2. ✅ Check if logo appears (معهد خباب logo)
3. ✅ Login to admin panel
4. ✅ Upload sample CSV (`data/sample_students.csv`)
5. ✅ Wait for QR codes to generate
6. ✅ Click "Publish Results"
7. ✅ Test student search
8. ✅ Print exam card

---

## 🎯 AFTER DEPLOYMENT

### Share with Students:

**URL to share:**
```
https://khabab-exam.onrender.com
```

**Share via:**
- WhatsApp group
- Telegram
- School notice board
- Print on papers

**Tell students:**
"Geli Exam Code-kaaga si aad u aragto natiijadaada"

---

## ⚠️ IMPORTANT NOTES

### Free Tier Limitations:

1. **Sleeps after 15 min inactive**
   - First visit may take 30 seconds to load
   - Normal after that

2. **750 hours/month free**
   - More than enough for most schools

3. **Files may be deleted on restart**
   - Re-upload CSV if needed
   - Solution: Upgrade to paid ($7/month) for permanent storage

---

## 🔄 UPDATE YOUR WEBSITE (When you make changes)

```bash
# 1. Make your changes
# 2. Upload to GitHub:

cd "C:\khabab Exam"
git add .
git commit -m "Updated system"
git push

# 3. Render will auto-deploy! (2-3 minutes)
```

---

## 🆘 TROUBLESHOOTING

### Problem: Website is slow

**Normal!** Free tier sleeps. First load = 30 seconds.

**Solution:** Patience OR upgrade to paid.

### Problem: Logo not showing

```bash
# Make sure logo is in GitHub:
git add assets/logo.png
git commit -m "Add logo"
git push
```

### Problem: Can't login to admin

**Check:** Environment variable `ADMIN_PASSWORD` on Render
- Go to Render dashboard
- Your service → Environment
- Verify password is correct

### Problem: QR codes not generating

**Wait 2-3 minutes** after CSV upload.
**Check logs** on Render dashboard.

### Problem: Students can't see results

**Check:** Click "Publish Results" in admin panel

---

## 💰 UPGRADE (Optional)

### Render Paid Plan: $7/month

Benefits:
- ✅ Always on (no sleep)
- ✅ Faster loading
- ✅ Permanent storage (QR codes won't be lost)
- ✅ Custom domain support

**To upgrade:**
1. Render dashboard
2. Your service
3. Settings → Instance Type
4. Select "Starter" ($7/month)

---

## 📱 CUSTOM DOMAIN (Optional)

Haddii aad rabto domain-kaaga (e.g., results.khabab.com):

1. Buy domain (Namecheap, GoDaddy)
2. Render dashboard → Your service → Settings
3. Custom Domain section
4. Follow instructions

---

## ✅ SUCCESS CHECKLIST

- [x] GitHub account created
- [x] Git installed
- [x] Code uploaded to GitHub
- [x] Render account created
- [x] Web service deployed
- [x] Environment variables set
- [x] Website is LIVE
- [x] Logo shows correctly
- [x] Admin login works
- [x] CSV upload works
- [x] Results publish works
- [x] Students can search
- [x] QR codes generate
- [x] Exam cards print

---

## 🎉 GUUL! SUCCESS!

**معهد خباب Exam Results System** 

Website-kaagu hadda wuxuu ku jiraa ONLINE! 🌍

**Share URL:**
```
https://khabab-exam.onrender.com
```

Ardayda ha isticmaalaan! ✅

---

**Questions? Eeg:**
- `ONLINE_DEPLOYMENT_GUIDE.md` - More details
- `README.md` - Full documentation
- Render Docs: https://render.com/docs

**Mahadsanid! Thank you!** 🙏

