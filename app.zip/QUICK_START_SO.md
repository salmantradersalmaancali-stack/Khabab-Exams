# 🎓 Habka Billowga - Somali Guide

## ✅ Waxaan dhammaystirmay / Completed

Waxa laysku soo koobay **nidaam buuxda oo loogu talagalay maaraynta natiijooyinka imtixaanada dugsiyada** oo ay ku jiraan:

### 🔐 Admin Panel (Maamulaha)
- Galitaan ammaan ah (username iyo password)
- Soo gelinta faylka CSV oo ku jira macluumaadka ardayda
- Si toos ah loo sameeyo QR codes ardey kasta
- Daabacaadda kaarka imtixaanka

### 👨‍🎓 Student Portal (Ardayga)
- Raadinta natiijooyinka iyadoo la isticmaalaayo Exam Code
- Iska skaanka QR code si loo arko natiijada
- Daabacaadda natiijada

## 📁 Meesha Logada (Logo Location)

**MUHIIM:** Logada dugsiga waxay ku taal **assets** folder:

```
assets/logo.png  ← Halkan geli sawirka logada dugsiga
```

### Sidee loo dhigo logada:

1. **Hel sawir logada dugsiga** (PNG ama JPG)
2. **Ugu dar folderka `assets`** folder
3. **U bixiya magaca** `logo.png`
4. **Cabbirka la talinayo**: 400x400 pixels

## 🚀 Sidee Loo Billaabiyo / How to Start

### Windows:
1. Double-click `run.bat`
2. Ama command prompt ku qor:
```bash
python app.py
```

### Mac/Linux:
```bash
bash run.sh
```

### Ama si fudud:
```bash
python app.py
```

## 🌐 Sidee Loo Isticmaalo / How to Use

### Maamulaha (Admin):

1. **Gal Admin Panel:**
   - Tag: `http://localhost:5000/admin/login`
   - Username: `admin`
   - Password: `admin123`

2. **Soo geli macluumaadka ardayda (CSV):**
   - Click "Choose CSV File"
   - Dooro faylka CSV
   - Click "Upload CSV"

3. **Daabac kaararka imtixaanka:**
   - Click "Print All Exam Cards"

4. **Daabac natiijooyinka:**
   - Click "Publish Results"

### Ardayga (Students):

1. Tag: `http://localhost:5000`
2. Geli Exam Code-ka
3. Click "View Result"

## 📝 Qaabka CSV File

CSV-ga waa inuu yeeshaa tirooyinkan:

| Tiir/Column | Tusaale/Example |
|-------------|-----------------|
| Name | Ahmed Mohamed |
| StudentID | 2024001 |
| ExamCode | EXAM2024001 |
| Marks | 85 |
| Grade | A |
| Subject | Mathematics |
| ExamDate | 2024-10-15 |

### Tusaale CSV:
```csv
Name,StudentID,ExamCode,Marks,Grade,Subject,ExamDate
Ahmed Mohamed,2024001,EXAM2024001,85,A,Mathematics,2024-10-15
Fadumo Ali,2024002,EXAM2024002,92,A+,Mathematics,2024-10-15
```

## 🔧 Wax ka beddel / Customize

### Magaca dugsiga beddel:

Fur `config.py` oo beddel:
```python
SCHOOL_NAME = 'Magaca Dugsigaaga'
```

### Password-ka beddel:
```python
ADMIN_USERNAME = 'admin_cusub'
ADMIN_PASSWORD = 'password_adag'
```

## 📱 Gelitaanka kale ee shabakada / Network Access

Si ardayda ay uga helaan kombuyutarrada kale:

1. **Hel IP address-kaaga:**
```bash
ipconfig  # Windows
ifconfig  # Mac/Linux
```

2. **Ardayda ha isticmaalaan:**
```
http://192.168.1.100:5000
```
(Beddel IP-ga mid kuu gaar ah)

## 🌐 Deployment (Online)

Si aad ugu soo gasho internetka, eeg:
- **DEPLOYMENT.md** - Tilmaamo buuxa
- Free hosting: Render, PythonAnywhere, Replit

## ❓ Caawimaad / Help

### Dhibaato QR codes:
- Check `static/qrcodes/` folder inay jirto
- Run: `python app.py` mar labaad

### CSV ma shaqaynayo:
- Check format-ka CSV-ga
- Ensure columns-yada saxda ah

### Logada ma muuqanayso:
- Check `assets/logo.png` inuu jiro
- Refresh browser (Ctrl + F5)

## 📞 Xiriir / Contact

Wax walba oo caawimaad ah, eeg:
- README.md - English guide
- SETUP_GUIDE.md - Detailed setup
- DEPLOYMENT.md - Online deployment

---

**Mahadsanid! / Thank you!** 🎉

Nidaamka diyaar buu u yahay isticmaalka!
The system is ready to use!

