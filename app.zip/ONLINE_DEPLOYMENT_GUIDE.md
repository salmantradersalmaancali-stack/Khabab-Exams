# 🌐 Tilmaamaha Online Deployment - معهد خباب

## 🚀 Hab 1: Render (RECOMMENDED - FREE ✅)

### Sababta Render waa tan ugu fiican:
- ✅ Bilaash 100% (Free forever)
- ✅ HTTPS automatic (ammaan)
- ✅ Easy setup (5-10 daqiiqo)
- ✅ GitHub integration
- ✅ No credit card required

---

## 📋 TALLAABOOYIN / STEPS

### Step 1: GitHub Account Samee

1. **Tag:** https://github.com
2. **Click:** "Sign up"
3. **Fill form:** Email, password, username
4. **Verify email**

### Step 2: Install Git (Windows)

1. **Download:** https://git-scm.com/download/win
2. **Install:** Click "Next" on everything
3. **Restart** computer (optional)

### Step 3: Upload Code to GitHub

```bash
# 1. Fur Command Prompt (cmd) or PowerShell
# 2. Navigate to project folder
cd "C:\khabab Exam"

# 3. Configure Git (first time only)
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# 4. Initialize repository
git init

# 5. Add all files
git add .

# 6. Commit
git commit -m "Khabab Institute Exam Results System"
```

**Hadda GitHub-ka tag:**

7. Click ➕ (top right) → "New repository"
8. Repository name: `khabab-exam-system`
9. Click "Create repository"
10. Copy commands shown and run:

```bash
git remote add origin https://github.com/YOUR-USERNAME/khabab-exam-system.git
git branch -M main
git push -u origin main
```

### Step 4: Deploy on Render

1. **Tag:** https://render.com
2. **Sign up** with GitHub account
3. **Click:** "New +" → "Web Service"
4. **Connect** your repository: `khabab-exam-system`
5. **Settings:**
   - Name: `khabab-exam`
   - Region: `Oregon (US West)` or closest
   - Branch: `main`
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`
   - Instance Type: **Free**

6. **Environment Variables** (click "Add Environment Variable"):
   
   ```
   ADMIN_PASSWORD = your-secure-password-here
   SECRET_KEY = any-random-text-here-123456
   SCHOOL_NAME = معهد خباب
   ```

7. **Click:** "Create Web Service"

8. **Wait:** 5-10 minutes for deployment

9. **Your URL:** `https://khabab-exam.onrender.com`

---

## 🎯 Marka Deploy-gu dhammaado / After Deployment

### ✅ Check Your Website:

- **Student Portal:** `https://khabab-exam.onrender.com`
- **Admin Panel:** `https://khabab-exam.onrender.com/admin/login`

### ⚠️ IMPORTANT - Free Tier Limitations:

1. **Sleep after 15 min inactivity** - First load will be slow (30 seconds)
2. **Limited bandwidth** - Good for small/medium schools
3. **No persistent storage** - QR codes may be lost on restart

### 💡 Solution for Storage:

Consider upgrading to paid tier ($7/month) OR use alternatives below.

---

## 🌟 Hab 2: PythonAnywhere (ALTERNATIVE - FREE)

### Faa'iidooyinka / Benefits:
- ✅ Free tier available
- ✅ Persistent storage
- ✅ Easy Python hosting
- ⚠️ Custom domain requires paid plan

### Steps:

1. **Sign up:** https://www.pythonanywhere.com
2. **Choose:** Beginner account (FREE)
3. **Upload files** via Files tab
4. **Create Web App:**
   - Go to "Web" tab
   - "Add new web app"
   - Python 3.10
   - Manual configuration

5. **Configure WSGI file:**
```python
import sys
import os

project_home = '/home/yourusername/khabab-exam'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

from app import app as application
```

6. **Install requirements:**
```bash
pip install --user -r requirements.txt
```

7. **Reload web app**

Your URL: `https://yourusername.pythonanywhere.com`

---

## 🎮 Hab 3: Replit (EASIEST BUT LIMITED)

### Faa'iidooyinka:
- ✅ Easiest setup (2 minutes)
- ✅ No GitHub needed
- ✅ Built-in code editor
- ⚠️ App sleeps when not in use

### Steps:

1. **Tag:** https://replit.com
2. **Sign up** (free)
3. **Click:** "Create Repl"
4. **Choose:** "Import from GitHub" OR "Upload folder"
5. **If uploading:** Zip your folder and upload
6. **Click:** "Run"
7. **Your URL:** Auto-generated (e.g., `https://khabab-exam.username.repl.co`)

---

## 🔒 Security Recommendations

### Before Going Live:

1. **Change Admin Password:**
   - In Render: Environment Variables
   - `ADMIN_PASSWORD = strong-password-here`

2. **Set Secret Key:**
   - `SECRET_KEY = random-string-minimum-32-characters`

3. **Update config.py** (if not using env vars):
```python
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD') or 'NEW-PASSWORD-HERE'
```

---

## 📱 Share with Students

Marka website-ku diyaar yahay:

1. **Student Portal URL:**
   ```
   https://your-app-name.onrender.com
   ```

2. **Share via:**
   - WhatsApp
   - Telegram
   - School website
   - Printed on exam cards (QR code)

3. **Admin Panel URL (DON'T SHARE):**
   ```
   https://your-app-name.onrender.com/admin/login
   ```

---

## 🆘 Troubleshooting

### Website ka daran ayuu shaqaynaya (Slow):

**Render Free Tier:** First load is slow (30 sec) after inactivity.
- **Solution:** Upgrade OR use a ping service

### QR codes ma muuqdaan:

**Check:** `static/qrcodes/` folder exists
- **Solution:** Re-upload CSV after deployment

### Logo ma muuqanayso:

**Check:** `assets/logo.png` is uploaded to GitHub
- **Solution:** 
```bash
git add assets/logo.png
git commit -m "Add logo"
git push
```
Then redeploy on Render.

### Students ku waayaan natiijooyinka:

**Check:** Results are published in admin panel
- Click "Publish Results" button

---

## 💰 Upgrade Options (Optional)

### Render Paid Plan ($7/month):
- ✅ Always-on (no sleep)
- ✅ Persistent storage
- ✅ Custom domain
- ✅ Better performance

### PythonAnywhere Paid ($5/month):
- ✅ Custom domain
- ✅ More bandwidth
- ✅ Better support

---

## 📊 Which Platform to Choose?

| Platform | Cost | Setup | Storage | Custom Domain | Recommended For |
|----------|------|-------|---------|---------------|-----------------|
| **Render** | Free/Paid | Medium | Temporary | Yes (Paid) | Best overall ⭐ |
| **PythonAnywhere** | Free/Paid | Medium | Permanent | Paid only | Good alternative |
| **Replit** | Free/Paid | Easy | Temporary | Paid only | Quick testing |

---

## ✅ Checklist Before Going Live

- [ ] Logo uploaded to GitHub (`assets/logo.png`)
- [ ] Admin password changed
- [ ] Secret key set
- [ ] CSV data ready
- [ ] Tested locally first
- [ ] Deployed to platform
- [ ] Tested online URL
- [ ] Admin panel accessible
- [ ] Student search works
- [ ] QR codes generate
- [ ] Results publish/unpublish works
- [ ] Exam cards print correctly

---

## 📞 Need More Help?

**Documentation:**
- Full guide: `DEPLOYMENT.md`
- Setup: `SETUP_GUIDE.md`
- Somali guide: `QUICK_START_SO.md`

**Render Support:**
- Docs: https://render.com/docs
- Community: https://community.render.com

---

## 🎉 Congratulations!

Your exam results system is now **ONLINE** and accessible from anywhere! 🌍

**معهد خباب Exam Results System** - Live and Ready! ✅

---

**Made with ❤️ for معهد خباب**

