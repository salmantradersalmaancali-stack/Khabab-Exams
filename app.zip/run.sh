#!/bin/bash

echo "================================"
echo "  Exam Results System Launcher"
echo "================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null
then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3 from https://python.org"
    exit 1
fi

echo "Python detected!"
echo ""

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    echo "Virtual environment created!"
    echo ""
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install requirements
echo "Checking dependencies..."
pip install -r requirements.txt --quiet
echo ""

# Create placeholder logo if it doesn't exist
if [ ! -f "assets/logo.png" ]; then
    echo "Creating placeholder logo..."
    python create_logo.py
    echo ""
fi

# Start the application
echo "================================"
echo "Starting the application..."
echo "================================"
echo ""
echo "Access the application at:"
echo "  - Student Portal: http://localhost:5000"
echo "  - Admin Panel: http://localhost:5000/admin/login"
echo ""
echo "Default admin credentials:"
echo "  Username: admin"
echo "  Password: admin123"
echo ""
echo "Press Ctrl+C to stop the server"
echo "================================"
echo ""

python app.py

