# 🎓 Online Exam Result Management System

A complete web-based examination result management system built with Flask, featuring admin panel, student portal, QR code generation, and printable exam cards.

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Flask](https://img.shields.io/badge/Flask-3.0.0-green.svg)
![License](https://img.shields.io/badge/license-MIT-blue.svg)

## ✨ Features

### 🔐 Admin Panel
- Secure login system with username/password authentication
- Upload CSV files containing student exam data
- Automatically generate QR codes for each student
- Publish/Unpublish results with one click
- View all students in a comprehensive dashboard
- Print individual or bulk exam cards
- Real-time status tracking

### 👨‍🎓 Student Portal
- Search results by Exam Code
- Scan QR code to directly view results
- Beautiful, printable result slips
- Responsive design for all devices
- "Results not yet released" message before publication

### 🎫 Exam Card System
- Automatically generated exam cards with QR codes
- Printable design (A4 size)
- Includes student details and QR code
- Bulk print all cards at once
- Professional layout with school branding

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Installation

1. **Clone or download this project**
```bash
cd exam-results-system
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Run the application**
```bash
python app.py
```

4. **Access the application**
- Open your browser and go to: `http://localhost:5000`
- Admin panel: `http://localhost:5000/admin/login`
- Student portal: `http://localhost:5000/search`

### Default Admin Credentials
- **Username:** `admin`
- **Password:** `admin123`

⚠️ **Important:** Change these credentials in production!

## 📁 Project Structure

```
exam-results-system/
├── app.py                 # Main Flask application
├── config.py              # Configuration settings
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── DEPLOYMENT.md         # Deployment guide
│
├── templates/            # HTML templates
│   ├── admin_login.html
│   ├── admin_dashboard.html
│   ├── student_search.html
│   ├── result.html
│   └── exam_card.html
│
├── static/               # Static files
│   ├── css/
│   │   └── style.css    # Main stylesheet
│   ├── js/
│   │   └── main.js      # JavaScript functionality
│   └── qrcodes/         # Generated QR codes (auto-created)
│
├── assets/              # Assets folder
│   └── logo.png         # School logo (add your own)
│
└── data/                # Data files
    ├── students.csv     # Uploaded student data (auto-created)
    └── sample_students.csv  # Sample data
```

## 📝 CSV File Format

Your CSV file must contain these columns (in any order):

| Column Name | Description | Required |
|-------------|-------------|----------|
| Name | Student's full name | ✅ Yes |
| StudentID | Unique student identifier | ✅ Yes |
| ExamCode | Unique exam code | ✅ Yes |
| Marks | Marks obtained | ✅ Yes |
| Grade | Grade (A+, A, B+, etc.) | ✅ Yes |
| Subject | Subject name | ⚪ Optional |
| ExamDate | Date of examination | ⚪ Optional |

### Example CSV:
```csv
Name,StudentID,ExamCode,Marks,Grade,Subject,ExamDate
John Doe,2024001,EXAM2024001,85,A,Mathematics,2024-10-15
Jane Smith,2024002,EXAM2024002,92,A+,Mathematics,2024-10-15
```

A sample CSV file is included in `data/sample_students.csv`.

## 🎯 How to Use

### For Administrators

1. **Login to Admin Panel**
   - Go to `/admin/login`
   - Enter username and password
   - Click "Login"

2. **Upload Student Data**
   - Click "Choose CSV File"
   - Select your CSV file
   - Click "Upload CSV"
   - Wait for QR codes to be generated

3. **Publish Results**
   - Click "Publish Results" button
   - Results will be visible to students immediately
   - Click "Unpublish Results" to hide them

4. **Print Exam Cards**
   - Click "Print All Exam Cards" to print all at once
   - Or click "Exam Card" for individual students
   - Use browser print function (Ctrl+P)

### For Students

1. **Search by Exam Code**
   - Go to the homepage
   - Enter your Exam Code
   - Click "View Result"

2. **Scan QR Code**
   - Use any QR code scanner app
   - Scan the QR code on your exam card
   - Your result will open automatically

3. **Print Result**
   - Click "Print Result" button on the result page
   - Or use Ctrl+P / Cmd+P

## ⚙️ Configuration

Edit `config.py` to customize:

```python
# Admin credentials
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'

# School information
SCHOOL_NAME = 'ABC International School'
SCHOOL_LOGO = 'static/images/logo.png'
```

### Adding Your School Logo

1. Place your school logo in the `assets` folder as `logo.png`
2. Recommended size: 400x400 pixels
3. Supported formats: PNG, JPG, SVG

## 🌐 Deployment

See [DEPLOYMENT.md](DEPLOYMENT.md) for detailed deployment instructions for:
- Render (Free hosting)
- PythonAnywhere
- Heroku
- Replit
- Local network deployment

## 🔒 Security Recommendations

1. **Change Default Credentials**
   ```python
   ADMIN_USERNAME = 'your_username'
   ADMIN_PASSWORD = 'your_strong_password'
   ```

2. **Set Secret Key**
   ```python
   SECRET_KEY = 'your-secret-key-here'
   ```

3. **Use Environment Variables** (Production)
   ```bash
   export ADMIN_USERNAME=admin
   export ADMIN_PASSWORD=strongpassword123
   export SECRET_KEY=your-random-secret-key
   ```

4. **Enable HTTPS** in production

## 🛠️ Troubleshooting

### QR Codes Not Generating
- Check if `static/qrcodes/` folder exists
- Ensure write permissions
- Check Python Pillow installation

### CSV Upload Fails
- Verify CSV format matches requirements
- Check column names are correct
- Ensure file is valid UTF-8 encoding

### Results Not Showing
- Check if results are published in admin panel
- Clear browser cache
- Verify student's ExamCode is correct

## 📱 Browser Compatibility

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Mobile browsers

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 💡 Future Enhancements

- [ ] Multiple exam support
- [ ] Email notifications
- [ ] SMS integration
- [ ] Advanced analytics
- [ ] Mobile app
- [ ] Multi-language support
- [ ] Database integration (SQLite/PostgreSQL)
- [ ] Bulk email results
- [ ] Parent portal

## 📞 Support

For support, please:
1. Check the troubleshooting section
2. Review the deployment guide
3. Create an issue on GitHub

## 🙏 Acknowledgments

- Flask web framework
- QRCode library
- Pandas for CSV processing
- Modern CSS design patterns

---

**Made with ❤️ for educational institutions**

