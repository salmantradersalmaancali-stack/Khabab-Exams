====================================
  ASSETS FOLDER - SCHOOL LOGO
====================================

This folder contains the school logo used throughout the exam results system.

REQUIRED FILE:
- logo.png (or logo.jpg)

INSTRUCTIONS:
1. Place your school's logo in this folder
2. Name it: logo.png
3. Recommended size: 400x400 pixels (square format)
4. Supported formats: PNG, JPG, SVG

The logo will appear on:
- Admin login page
- Admin dashboard
- Student search page
- Result pages
- Exam cards (printable)

If you don't have a logo ready, run:
  python create_logo.py

This will create a placeholder logo that you can replace later.

====================================

