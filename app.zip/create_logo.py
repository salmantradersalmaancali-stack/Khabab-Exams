"""
Simple script to create a placeholder school logo
Run this if you don't have a logo ready
"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_placeholder_logo():
    # Create a 400x400 image with a nice background
    img = Image.new('RGB', (400, 400), color='#2563eb')
    draw = ImageDraw.Draw(img)
    
    # Draw a white circle
    draw.ellipse([50, 50, 350, 350], fill='white', outline='#1e40af', width=5)
    
    # Draw inner circle
    draw.ellipse([100, 100, 300, 300], fill='#2563eb', outline='white', width=3)
    
    # Add text
    try:
        # Try to use a nice font if available
        font_large = ImageFont.truetype("arial.ttf", 60)
        font_small = ImageFont.truetype("arial.ttf", 30)
    except:
        # Fallback to default font
        font_large = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    # Draw school initials or icon
    text = "SCHOOL"
    bbox = draw.textbbox((0, 0), text, font=font_large)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    x = (400 - text_width) / 2
    y = (400 - text_height) / 2 - 20
    draw.text((x, y), text, fill='white', font=font_large)
    
    text2 = "LOGO"
    bbox2 = draw.textbbox((0, 0), text2, font=font_small)
    text_width2 = bbox2[2] - bbox2[0]
    x2 = (400 - text_width2) / 2
    y2 = y + text_height + 10
    draw.text((x2, y2), text2, fill='white', font=font_small)
    
    # Save the image
    logo_path = os.path.join('assets', 'logo.png')
    os.makedirs(os.path.dirname(logo_path), exist_ok=True)
    img.save(logo_path)
    print(f"✅ Placeholder logo created at: {logo_path}")
    print("⚠️  Remember to replace this with your actual school logo!")

if __name__ == '__main__':
    create_placeholder_logo()

